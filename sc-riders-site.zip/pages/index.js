import { useState } from "react";

export default function HomePage() {
  const [email, setEmail] = useState("");

  return (
    <div className="bg-black text-white min-h-screen font-sans">
      <header className="flex justify-between items-center p-6 border-b border-white">
        <img src="/logo.png" alt="SC Riders" className="h-12" />
        <nav className="space-x-4">
          <a href="#loja" className="hover:text-sand">Loja</a>
          <a href="#manifesto" className="hover:text-sand">Manifesto</a>
          <a href="#comunidade" className="hover:text-sand">Comunidade</a>
          <a href="#portfolio" className="hover:text-sand">Portfólio</a>
          <a href="#blog" className="hover:text-sand">Blog</a>
        </nav>
      </header>

      <main className="p-6">
        <section className="relative h-[90vh] flex flex-col items-center justify-center text-center bg-cover bg-center" style={{ backgroundImage: "url('/hero.jpg')" }}>
          <div className="bg-black bg-opacity-60 p-6 rounded-xl">
            <h1 className="text-4xl md:text-6xl font-bold">Liberdade não se explica. Se vive.</h1>
            <p className="mt-4 text-xl text-gray-300">Vista sua jornada. Sinta a estrada com a SC Riders.</p>
            <button className="mt-6 bg-white text-black px-4 py-2 rounded hover:bg-sand">Conheça a coleção</button>
          </div>
        </section>

        <section id="manifesto" className="py-16 border-t border-white bg-gray-900">
          <h2 className="text-3xl font-bold text-center">Manifesto</h2>
          <p className="max-w-3xl mx-auto text-center text-gray-300 text-lg mt-6">Somos mais que uma marca. Somos o ronco na estrada, o cheiro de poeira, a chuva no visor e o nascer do sol na serra. Cada peça da SC Riders carrega o espírito de quem escolhe a liberdade como estilo de vida. Aqui, cada curva é uma história, cada quilômetro, um manifesto de quem não abre mão de viver intensamente.</p>
        </section>
      </main>

      <footer className="text-center p-6 border-t border-white text-gray-500 text-sm">
        © {new Date().getFullYear()} SC Riders. Todos os direitos reservados.
      </footer>
    </div>
  );
}
